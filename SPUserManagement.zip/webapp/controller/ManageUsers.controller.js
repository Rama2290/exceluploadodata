sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/m/MessageBox",
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportTypeCSV",
	"sap/ui/export/Spreadsheet",
	"sap/m/MessageToast",
	"SPUser/lib/jszip",
	"SPUser/lib/xlsx"
], function(Controller, JSONModel, Filter, MessageBox, Spreadsheet, Export, ExportTypeCSV, MessageToast, jszip, xlsx) {
	"use strict";
	//var XLSX =xlsx.XLSX;
	return Controller.extend("SPUser.controller.ManageUsers", {

		onInit: function() {
			this._oView = this.getView();
			this._oRouter = this.getOwnerComponent().getRouter();

			var oView = new JSONModel({
				massUpload: false,
				incremental: false,
				selIndex: -1
			});
			this.getView().setModel(oView, "View");
			var oPayloadModel = new JSONModel({
				"Userid": "",
				"ReqType": "",
				"USRREQTOMGT_N": {
					"results": []
				}
			});
			this.getView().setModel(oPayloadModel, "Payload");
		},
		onAfterRendering: function() {
			var oUserModel = new JSONModel();
			var oModel = this.getView().getModel();
			var that = this;
			oModel.read("/ZUSR_MGTTYPSet('DUMMY')", {
				urlParameters: {
					"$expand": "USRREQTOMGT_N"
				},
				success: function(data) {
					var resJson = data.USRREQTOMGT_N.results;
					oUserModel.setJSON(JSON.stringify(resJson));
					that.getView().setModel(oUserModel, "Users");
				},
				error: function(oError) {
					var err = oError;
				}
			});
		},
		createColumnConfig: function() {

			var aCols = [];

			aCols.push({
				property: 'Userid',
				type: 'string'
			});
			aCols.push({
				property: 'Role',
				type: 'string'

			});
			aCols.push({
				property: 'Name',
				type: 'string'
			});
			aCols.push({
				property: 'EmailId',
				type: 'string'
			});
			aCols.push({
				property: 'Directorate',
				type: 'string'
			});
			aCols.push({
				property: 'DirectorateTxt',
				type: 'string'
			});
			aCols.push({
				property: 'Unit',
				type: 'string'
			});
			aCols.push({
				property: 'UnitTxt',
				type: 'string'
			});
			aCols.push({
				property: 'OrgUnit',
				type: 'string'
			});

			return aCols;

		},
		onDataExport: function() {
			var aBoundProperties, aCols, oProperties, oRowBinding, oSettings, oTable;

			//	oController = this;

			if (!this._oTable) {
				this._oTable = this.byId("idUsersTable");
			}

			oTable = this._oTable;
			oRowBinding = oTable.getBinding("items");

			aCols = this.createColumnConfig();

			var oModel = oRowBinding.getModel();
			var oModelInterface = oModel.getInterface();

			oSettings = {
				workbook: {
					columns: aCols
				},
				context: {
					sheetName: "User Management Table"
				},
				dataSource: {
					type: "oData",
					dataUrl: "/GF4/sap/opu/odata/sap/zhr_assmnt_keypos_srv/ZUSR_MGTSet",
					serviceUrl: "/GF4/sap/opu/odata/sap/zhr_assmnt_keypos_srv",
					headers: oModelInterface.getHeaders ? oModelInterface.getHeaders() : null,
					count: oRowBinding.getLength ? oRowBinding.getLength() : null,
					useBatch: false,
					sizeLimit: oModelInterface.iSizeLimit
				},
				fileName: "Users.xlsx"
			};

			var oSpreadSheet = new sap.ui.export.Spreadsheet(oSettings);
			oSpreadSheet.onprogress = function(iValue) {
				//	var oProgInd =	new sap.m.ProgressIndicator("idPrg", {displayValue : iValue,percentValue : iValue,state : sap.ui.core.ValueState.Success});
				jQuery.sap.log.debug("Export: " + iValue + "% completed");
			};
			oSpreadSheet.cancel = function() {
				oSpreadSheet.cancel();
			};
			oSpreadSheet.build();
		},
		onDataImport: function(oEvent) {
			// create popover
			if (!this._oPopoverFileUploader) {
				this._oPopoverFileUploader = sap.ui.xmlfragment("SPUser.fragment.FileUploader", this);
				this.getView().addDependent(this._oPopoverFileUploader);
			}
			this._oPopoverFileUploader.openBy(oEvent.getSource());
		},
		onRadioBtnSelected: function(oEvent) {
			var sSelBtnText = oEvent.getSource().getSelectedButton().getText();
			var oTable = this.getView().byId("idUsersTable");
			var oViewModel = this.getView().getModel("View");
			if (sSelBtnText === "Mass Upload") {
				oTable.setMode("None");
				oViewModel.setProperty("/massUpload", true);
				oViewModel.setProperty("/incremental", false);
			} else if (sSelBtnText === "Incremental") {
				oViewModel.setProperty("/massUpload", false);
				oViewModel.setProperty("/incremental", true);
			}
			this._refreshTable();
			oViewModel.refresh(true);
		},
		onUpdateOptionSelected: function(oEvent) {
			var sSelBtnText = oEvent.getSource().getSelectedButton().getText();
			var iRowIndex = oEvent.getSource().getId().split("-")[4];
			var oUserModel = this.getView().getModel("Users");
			if (sSelBtnText === "Edit") {
				oUserModel.setProperty("/" + iRowIndex + "/Chgind", "E");
			} else if (sSelBtnText === "Delete") {
				oUserModel.setProperty("/" + iRowIndex + "/Chgind", "D");
			}
		},
		onAdd: function() {
			var oUserModel = this.getView().getModel("Users");
			var userArr = oUserModel.getData();
			var aJson = {
				Directorate: "",
				Userid: "",
				Unit: "",
				DirectorateTxt: "",
				Role: "",
				UnitTxt: "",
				Name: "",
				OrgUnit: "",
				EmailId: "",
				OrgUnitTxt: "",
				Chgind: "I"
			};
			userArr.unshift(aJson);
			oUserModel.refresh(true);
		},
		onEdit: function() {
			var oTable = this.getView().byId("idUsersTable");
			var sMode = oTable.getMode();
			var snewMode = oTable.getMode() === "None" ? "Delete" : "None";
			oTable.setMode(snewMode);
		},
		onDelete: function(oEvent) {
			var oTable = this.getView().byId("idUsersTable");
			var oUserModel = this.getView().getModel("Users");
			var iDelIndex = oEvent.getParameters("listItem").listItem.getId().split("-")[4];
			var userArr = oUserModel.getData();
			userArr.splice(iDelIndex, 1);
			oUserModel.refresh(true);
		},

		onPressUpdate: function() {
			sap.ui.core.BusyIndicator.show();
			var oTable = this.getView().byId("idUsersTable");
			var oUserData = oTable.getBinding("items").getModel().getData();
			var sReqType = this.getView().byId("idUploadOption").getSelectedButton().getText();
			var oPayload = this.getView().getModel("Payload");
			var oPayloadData = oPayload.getData();
			if (sReqType === "Mass Upload") {
				oPayloadData.ReqType = "MASS";
			} else if (sReqType === "Incremental") {
				oPayloadData.ReqType = "INDV";
			}

			oPayloadData.USRREQTOMGT_N.results = oUserData;
			oPayload.refresh(true);
			var that = this;
			var oModel = this.getView().getModel();
			oModel.create("/ZUSR_MGTTYPSet",
				oPayloadData, {
					put: true,
					success: function(oResponse) {
						sap.ui.core.BusyIndicator.hide();
						var oResourceModel = that.getView().getModel("i18n").getResourceBundle();
						var sMsg = oResourceModel.getText("successMsg");
						MessageToast.show(sMsg);
						that._refreshTable();
						//	that._navBack();
					},
					error: function(oError, oresponse) {
						sap.ui.core.BusyIndicator.hide();
						var oErr = JSON.parse(oError.responseText);
						var aErrorMessages = oErr.error.innererror.errordetails;
						var iSize = aErrorMessages.length;
						var sErrMessage = "";
						for (var i = 0; i < iSize; i++) {
							sErrMessage += aErrorMessages[i].message + "\n";
						}
						MessageBox.error(JSON.parse(oError.responseText).error.message.value);
						that._navBack();
					}
				});

		},

		handleUploadComplete: function(oEvent) {
			var sResponse = oEvent.getParameter("response");
			if (sResponse) {
				var sMsg = "";
				var m = /^\[(\d\d\d)\]:(.*)$/.exec(sResponse);
				if (m[1] == "200") {
					sMsg = "Return Code: " + m[1] + "\n" + m[2] + "(Upload Success)";
					oEvent.getSource().setValue("");
				} else {
					sMsg = "Return Code: " + m[1] + "\n" + m[2] + "(Upload Error)";
				}

				MessageToast.show(sMsg);
			}
		},

		handleUploadPress: function(oEvent) {
			var oFileUploader = oEvent.getSource().getParent().getContent()[0];
			if (!oFileUploader.getValue()) {
				MessageToast.show("Choose a file first");
				return;
			}
			this._import(oFileUploader.oFileUpload.files && oFileUploader.oFileUpload.files[0]);
			oFileUploader.setValue("");
			oEvent.getSource().getParent().close();
		},

		handleTypeMissmatch: function(oEvent) {
			var aFileTypes = oEvent.getSource().getFileType();
			jQuery.each(aFileTypes, function(key, value) {
				aFileTypes[key] = "*." + value;
			});
			var sSupportedFileTypes = aFileTypes.join(", ");
			MessageToast.show("The file type *." + oEvent.getParameter("fileType") +
				" is not supported. Choose one of the following types: " +
				sSupportedFileTypes);
		},

		handleValueChange: function(oEvent) {
			MessageToast.show("Press 'Upload File' to upload file '" +
				oEvent.getParameter("newValue") + "'");
		},
		_import: function(file) {
			var bEmptyFile = false;
			var bIncorrectFormat = false;
			if (file && window.FileReader) {

				var reader = new FileReader();
				var excelFileData = {};
				var result = {},
					data;
				var wb, sCsvdata;
				var that = this;

				var oUserModel = this.getView().getModel("Users");
				reader.onload = function(e) {

					data = e.target.result;

					wb = XLSX.read(data, {
						type: 'binary'
					});

					wb.SheetNames.forEach(function(sheetName) {
						var scolumnNames, sColArr, validFile;

						sCsvdata = XLSX.utils.make_csv(wb.Sheets[sheetName]);
						if (sCsvdata && sCsvdata !== "") {
							scolumnNames = sCsvdata.split("\n")[0];
							if (scolumnNames && scolumnNames !== "") {
								sColArr = scolumnNames.split(",");
								validFile = that._validateExcelColumns(sColArr);
							}
						} else {
							bEmptyFile = true;
						}

						if (validFile) {
							var roa = XLSX.utils.sheet_to_row_object_array(wb.Sheets[sheetName]);
							if (roa.length > 0) {

								result[sheetName] = roa;
								excelFileData = result[sheetName];
								oUserModel.setJSON(JSON.stringify(excelFileData));
								oUserModel.refresh(true);
							}
						} else {
							bIncorrectFormat = true;
							MessageBox.error("Uploaded fie data format is incorrect. Please upload file in proper format");
						}

					});

					return result;

				};

				reader.readAsBinaryString(file);

			}
			if (bEmptyFile){
				MessageBox.error("Uploaded file is empty. Please upload a valid file.");	
			}
			else if(bIncorrectFormat){
				MessageBox.error("Uploaded fie data format is incorrect. Please upload file in proper format");
			}
		},
		_validateExcelColumns: function(aCols) {
			var sValid;
			var iLen = aCols.length;
			if (iLen === 9) {
				if (aCols[0] === "Userid" && aCols[1] === "Role" && aCols[2] === "Name" && aCols[3] === "EmailId" && aCols[4] === "Directorate" &&
					aCols[5] === "DirectorateTxt" && aCols[6] === "Unit" && aCols[7] === "UnitTxt" && aCols[8] === "OrgUnit") {
					sValid = true;
				} else {
					sValid = false;
				}
			} else {
				sValid = false;
			}
			return sValid;
		},
		_refreshTable: function() {
			var oUserModel = this.getView().getModel("Users");
			var oModel = this.getView().getModel();

			oModel.read("/ZUSR_MGTTYPSet('DUMMY')", {
				urlParameters: {
					"$expand": "USRREQTOMGT_N"
				},
				success: function(data) {
					var resJson = data.USRREQTOMGT_N.results;
					oUserModel.setJSON(JSON.stringify(resJson));
					oUserModel.refresh(true);
				},
				error: function(oError) {
					var err = oError;
				}
			});
		}
	});
});